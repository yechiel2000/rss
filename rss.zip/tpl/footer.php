<footer id="footer" class="footer bg-overlay">
    <div class="footer-main">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="banner-heading">
                        <h1 class="banner-title">רוז שירותי תוכנה</h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="banner-heading">
                        <p style="color:white;margin-top:20px;">טל.:&nbsp; 0508579379</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="banner-heading">
                        <p style="color:white;margin-top:10px;">yechiel2000@gmail.com &nbsp;:מייל </p>
                    </div>
                </div>
            </div>

        </div><!-- Container end -->
    </div><!-- Footer main end -->

    <div class="copyright">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="copyright-info text-center">
                        <span>Copyright &copy;
                            <script>
                            document.write(new Date().getFullYear())
                            </script>, תוכנן ונבנה ע"י: <a style="text-decoration: underline;color:blue"
                                href="http://rss2018.xyz">רוז שירותי
                                תוכנה</a>
                        </span>
                    </div>
                </div>
            </div><!-- Row end -->

            <div id="back-to-top" data-spy="affix" data-offset-top="10" class="back-to-top position-fixed">
                <button class="btn btn-primary" title="Back to Top">
                    <i class="fa fa-angle-double-up"></i>
                </button>
            </div>

        </div><!-- Container end -->
    </div><!-- Copyright end -->
</footer><!-- Footer end -->
<!-- Javascript Files
  ================================================== -->

<!-- initialize jQuery Library -->
<script src="plugins/jQuery/jquery.min.js"></script>
<!-- Bootstrap jQuery -->
<script src="plugins/bootstrap/bootstrap.min.js" defer></script>
<!-- Slick Carousel -->
<script src="plugins/slick/slick.min.js"></script>
<script src="plugins/slick/slick-animation.min.js"></script>
<!-- Color box -->
<script src="plugins/colorbox/jquery.colorbox.js"></script>
<!-- shuffle -->
<script src="plugins/shuffle/shuffle.min.js" defer></script>


<!-- Google Map API Key-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU" defer></script>
<!-- Google Map Plugin-->
<script src="plugins/google-map/map.js" defer></script>

<!-- Template custom -->
<script src="js/script.js"></script>

</div><!-- Body inner end -->
<script>
nl_contact = "n:יחיאל|p:0508579379|u:yechiel2000+d:gmail.com";
</script>
<script src="https://rss2018.xyz/plugins/nagishli/nagishli.js?v=2.3" charset="utf-8" defer></script>
</body>

</html>